-- As operações precisam de ';' no final, ao utilizar o H2

insert into TB001_PRODUCT (
    NAME,
    PRICE
) values
('Miojo', 3.50),
('Feijão', 7.80),
('Macarrão', 4.20),
('Alface', 1.10);